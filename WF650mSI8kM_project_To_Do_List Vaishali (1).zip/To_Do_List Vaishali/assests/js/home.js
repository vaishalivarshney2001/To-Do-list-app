// due date starting form today
document.querySelector("#duedate").min = new Date().toISOString().slice(0, 10);
